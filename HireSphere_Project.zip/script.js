const jobsData = [
{title:"Frontend Developer"},
{title:"Data Scientist"},
{title:"Product Manager"}
];

function renderJobs(jobs){
const grid=document.getElementById("jobsGrid");
grid.innerHTML=jobs.map(j=>`<p>${j.title}</p>`).join("");
}

function filterJobs(){
const skill=document.getElementById("filterSkill").value.toLowerCase();
const results=jobsData.filter(j=>j.title.toLowerCase().includes(skill));
renderJobs(results);
}

document.addEventListener("DOMContentLoaded",()=>renderJobs(jobsData));
